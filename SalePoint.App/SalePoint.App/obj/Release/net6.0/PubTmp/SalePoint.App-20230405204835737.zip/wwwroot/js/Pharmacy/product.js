﻿$(document).ready(() => {
    getAllProducts().then((products) => {
        if (products != null && products.length > 0) {
            buildTableProducts(products);
        }
    });
});

const buildTableProducts = (products) => {

    let data = new Array();

    products.map((item) => {

        data.push({
            'id': item.id,
            'name': item.name,
            'barCode': item.barCode,
            'expirationDate': new Date(item.expirationDate).toLocaleDateString(),
            'description': item.description,
            'stock': item.stock,
            'minimumStock': item.minimumStock,
            'purchasePrice': item.purchasePrice,
            'sellingPrice': item.sellingPrice,
            'revenue': item.revenue,
            'isActive': item.isActive,
            'creationDate': `${new Date(item.creationDate).toLocaleDateString()} ${new Date(item.creationDate).toLocaleTimeString() }`,
            'modificationDate': item.modificationDate,
            'deletionDate': item.deletionDate,
            'userId': item.userId
        });
    });

    $('#tableProducts').DataTable({
        data: data,
        columns: [
            { data: 'id' },
            { data: 'name' },
            { data: 'barCode' },
            { data: 'expirationDate' },
            { data: 'description' },
            { data: 'stock' },
            { data: 'minimumStock' },
            { data: 'purchasePrice' },
            { data: 'sellingPrice' },
            { data: 'revenue' },
            { data: 'isActive' },
            { data: 'creationDate' },
            { data: 'modificationDate' },
            { data: 'deletionDate' },
            { data: 'userId' }
        ]
    });

}

const getAllProducts = async () => {
    let data = new Array();
    const url = `${window.location.href}/GetAllProducts`;

    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    });

    data = await response.json();

    return data;
}